import "./App.css";
import Converter from "./Components/Pages/Converter/Converter";
function App() {
  return (
    <div className="App">
      <Converter />
    </div>
  );
}

export default App;
