const Modal = () => {
    return (
        <div>
            
        </div>
    )
}

export default Modal
